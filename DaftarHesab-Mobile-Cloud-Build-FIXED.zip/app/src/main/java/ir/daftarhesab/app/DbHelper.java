package ir.daftarhesab.app;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;

public class DbHelper extends SQLiteOpenHelper {
    public static final String DB_NAME = "daftar_hesab.db";
    public DbHelper(Context c) { super(c, DB_NAME, null, 2); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT DEFAULT '')");
        db.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, price INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE TABLE transactions(id INTEGER PRIMARY KEY AUTOINCREMENT, customer_id INTEGER NOT NULL, type TEXT NOT NULL, amount INTEGER NOT NULL, note TEXT DEFAULT '', created_at INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE transaction_items(id INTEGER PRIMARY KEY AUTOINCREMENT, transaction_id INTEGER NOT NULL, product_name TEXT NOT NULL, qty REAL NOT NULL, unit_price INTEGER NOT NULL, line_total INTEGER NOT NULL)");
        db.execSQL("CREATE INDEX idx_transactions_customer ON transactions(customer_id, created_at)");
        db.execSQL("CREATE TABLE settings(setting_key TEXT PRIMARY KEY, setting_value TEXT NOT NULL DEFAULT '')");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if(oldVersion<2) db.execSQL("CREATE TABLE IF NOT EXISTS settings(setting_key TEXT PRIMARY KEY, setting_value TEXT NOT NULL DEFAULT '')");
    }
    public String getSetting(String key,String fallback) {
        Cursor c=getReadableDatabase().rawQuery("SELECT setting_value FROM settings WHERE setting_key=?",new String[]{key});
        String value=fallback; if(c.moveToFirst()) value=c.getString(0); c.close(); return value;
    }
    public void setSetting(String key,String value) {
        ContentValues v=new ContentValues();v.put("setting_key",key);v.put("setting_value",value);
        getWritableDatabase().insertWithOnConflict("settings",null,v,SQLiteDatabase.CONFLICT_REPLACE);
    }
    public long addCustomer(String name, String phone) {
        ContentValues v=new ContentValues(); v.put("name",name); v.put("phone",phone);
        return getWritableDatabase().insert("customers",null,v);
    }
    public long addProduct(String name,long price) {
        ContentValues v=new ContentValues(); v.put("name",name); v.put("price",price);
        return getWritableDatabase().insert("products",null,v);
    }
    public long addTransaction(long customerId,String type,long amount,String note) {
        ContentValues v=new ContentValues(); v.put("customer_id",customerId); v.put("type",type); v.put("amount",amount); v.put("note",note); v.put("created_at",System.currentTimeMillis());
        return getWritableDatabase().insert("transactions",null,v);
    }
    public void addItem(long txId,String name,double qty,long price) {
        ContentValues v=new ContentValues(); v.put("transaction_id",txId); v.put("product_name",name); v.put("qty",qty); v.put("unit_price",price); v.put("line_total",Math.round(qty*price));
        getWritableDatabase().insert("transaction_items",null,v);
    }
    public Cursor customers() { return getReadableDatabase().rawQuery("SELECT id,name,phone FROM customers ORDER BY name",null); }
    public Cursor products() { return getReadableDatabase().rawQuery("SELECT id,name,price FROM products ORDER BY name",null); }
    public Cursor transactionsFor(long id) { return getReadableDatabase().rawQuery("SELECT type,amount,note,created_at FROM transactions WHERE customer_id=? ORDER BY created_at DESC",new String[]{String.valueOf(id)}); }
    public Cursor transactionsForPrint(long id) { return getReadableDatabase().rawQuery("SELECT type,amount,note,created_at FROM transactions WHERE customer_id=? ORDER BY created_at ASC, id ASC",new String[]{String.valueOf(id)}); }
    public long balance(long id) {
        Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(CASE WHEN type='BUY' THEN amount WHEN type='PAY' THEN -amount WHEN type='CREDIT' THEN -amount WHEN type='RETURN' THEN -amount ELSE 0 END),0) FROM transactions WHERE customer_id=?",new String[]{String.valueOf(id)});
        long b=0; if(c.moveToFirst()) b=c.getLong(0); c.close(); return b;
    }
    public long totalReceivable() { return scalar("SELECT COALESCE(SUM(CASE WHEN bal>0 THEN bal ELSE 0 END),0) FROM (SELECT SUM(CASE WHEN type='BUY' THEN amount WHEN type IN ('PAY','CREDIT','RETURN') THEN -amount ELSE 0 END) AS bal FROM transactions GROUP BY customer_id)"); }
    public int customerCount() { return (int)scalar("SELECT COUNT(*) FROM customers"); }
    public long totalCredit() { return scalar("SELECT COALESCE(SUM(CASE WHEN bal<0 THEN -bal ELSE 0 END),0) FROM (SELECT SUM(CASE WHEN type='BUY' THEN amount WHEN type IN ('PAY','CREDIT','RETURN') THEN -amount ELSE 0 END) AS bal FROM transactions GROUP BY customer_id)"); }
    private long scalar(String q) { Cursor c=getReadableDatabase().rawQuery(q,null); long n=0; if(c.moveToFirst())n=c.getLong(0); c.close(); return n; }
}
