package ir.daftarhesab.app;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.net.Uri;
import android.database.Cursor;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.print.PrintManager;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import java.io.*;
import java.text.*;
import java.util.*;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;

public class MainActivity extends Activity {
    DbHelper db; LinearLayout root, body; final int GREEN=0xFF0E6654, BG=0xFFF4F7F6, DARK=0xFF18332D;
    static class Customer { long id; String name, phone; Customer(long i,String n,String ph){id=i;name=n;phone=ph==null?"":ph;} public String toString(){return name;} }
    static class Product { long id,price; String name; Product(long i,String n,long p){id=i;name=n;price=p;} public String toString(){return name+" · "+money(price)+" تومان";} }
    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(GREEN); getWindow().setNavigationBarColor(GREEN); db=new DbHelper(this); showHome();}
    int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);t.setGravity(Gravity.RIGHT);t.setTextDirection(View.TEXT_DIRECTION_RTL);return t;}
    LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(16),dp(12),dp(16),dp(16));l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);return l;}

    android.graphics.drawable.GradientDrawable rounded(int color,int radius){
        android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    android.graphics.drawable.GradientDrawable gradient(int c1,int c2,int radius){
        android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable(
            android.graphics.drawable.GradientDrawable.Orientation.TL_BR,new int[]{c1,c2});
        d.setCornerRadius(dp(radius)); return d;
    }
    Button btn(String s,Runnable r){
        Button b=new Button(this); b.setText(s); b.setAllCaps(false); b.setTextColor(0xFFFFFFFF);
        b.setTextSize(14); b.setTypeface(null,Typeface.BOLD); b.setGravity(Gravity.CENTER);
        b.setPadding(dp(14),dp(11),dp(14),dp(11)); b.setBackground(gradient(0xFF536DFE,0xFF7952D8,17));
        b.setElevation(dp(3)); b.setOnClickListener(v->r.run());
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(9);b.setLayoutParams(p);
        return b;
    }
    void base(String title){
        root=column();root.setPadding(dp(14),dp(12),dp(14),dp(16));root.setBackgroundColor(0xFFF2F4FB);
        LinearLayout header=new LinearLayout(this);header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(20),dp(19),dp(20),dp(19));header.setBackground(gradient(0xFF243B88,0xFF7146C8,24));
        TextView h=text(title,23,0xFFFFFFFF,true);
        TextView sub=text("مدیریت هوشمند حساب‌های دفتری",12,0xFFE6E9FF,false);
        sub.setPadding(0,dp(5),0,0);header.addView(h);header.addView(sub);
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.bottomMargin=dp(14);root.addView(header,hp);
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);body=column();body.setPadding(0,0,0,dp(10));sc.addView(body);
        root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
    }

    void showHome(){
        base("دفتر حساب");
        TextView hello=text("سلام! امروز حساب‌ها را مرتب کنیم؟",16,0xFF29365F,true);
        hello.setPadding(dp(3),dp(2),dp(3),dp(10));body.addView(hello);
        TextView searchTitle=text("جست‌وجوی فوری مشتری",14,0xFF536DFE,true);
        searchTitle.setPadding(dp(3),0,dp(3),dp(7));body.addView(searchTitle);
        EditText search=field("نام یا شماره موبایل مشتری...");
        search.setSingleLine(true);search.setTextSize(15);search.setPadding(dp(16),dp(13),dp(16),dp(13));
        search.setCompoundDrawablesWithIntrinsicBounds(android.R.drawable.ic_menu_search,0,0,0);
        search.setBackground(rounded(0xFFFFFFFF,18));search.setElevation(dp(2));
        body.addView(search,new LinearLayout.LayoutParams(-1,dp(54)));
        LinearLayout results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams resP=new LinearLayout.LayoutParams(-1,-2);resP.topMargin=dp(7);body.addView(results,resP);
        Runnable update=()->{
            results.removeAllViews();String q=search.getText().toString().trim().toLowerCase(new Locale("fa","IR"));
            if(q.isEmpty())return;int count=0;
            for(Customer c:getCustomers()){
                String phone=c.phone==null?"":c.phone;
                if(c.name.toLowerCase(new Locale("fa","IR")).contains(q)||phone.replaceAll("\\s+","").contains(q.replaceAll("\\s+",""))){
                    long bal=db.balance(c.id);String st=bal>0?"بدهکار":bal<0?"بستانکار":"تسویه";
                    TextView item=text(c.name+"   ·   "+st+"\\n"+phone+"     "+money(Math.abs(bal))+" تومان",14,
                        bal>0?0xFFDF5265:bal<0?0xFF159D83:0xFF52617E,true);
                    item.setPadding(dp(15),dp(13),dp(15),dp(13));item.setBackground(rounded(0xFFFFFFFF,15));item.setElevation(dp(1));
                    item.setOnClickListener(v->customerDetail(c));
                    LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,-2);ip.bottomMargin=dp(6);results.addView(item,ip);
                    if(++count>=7)break;
                }
            }
            if(count==0)results.addView(text("مشتری‌ای با این مشخصات پیدا نشد",13,0xFF7B849B,false));
        };
        search.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence a,int st,int count,int after){}
            public void onTextChanged(CharSequence a,int st,int before,int count){update.run();}
            public void afterTextChanged(Editable e){}
        });
        TextView summary=text("نمای کلی حساب‌ها",17,0xFF29365F,true);
        summary.setPadding(dp(3),dp(14),dp(3),dp(8));body.addView(summary);
        card("مطالبات از مشتریان",money(db.totalReceivable())+" تومان",0xFFDF5265);
        card("بستانکاری مشتریان",money(db.totalCredit())+" تومان",0xFF159D83);
        card("تعداد مشتریان",money(db.customerCount())+" نفر",0xFF536DFE);
        TextView quick=text("دسترسی‌های سریع",17,0xFF29365F,true);
        quick.setPadding(dp(3),dp(12),dp(3),dp(8));body.addView(quick);
        body.addView(btn("＋  ثبت مشتری جدید",()->addCustomer()));
        body.addView(btn("👥  فهرست مشتریان و حساب‌ها",()->showCustomers()));
        body.addView(btn("🧾  ثبت خرید / پرداخت / اعتبار",()->chooseCustomerForTx()));
        body.addView(btn("📦  مدیریت کالاها",()->showProducts()));
        body.addView(btn("📊  گزارش بدهکاران و بستانکاران",()->showReports()));
        body.addView(btn("💾  تهیه نسخه پشتیبان",()->backup()));
        body.addView(btn("♻  بازیابی نسخه پشتیبان",()->restore()));
        body.addView(btn("⚙  اطلاعات و مشخصات سوپرمارکت",()->shopSettings()));
    }
    void card(String label,String value,int color){
        LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(17),dp(14),dp(17),dp(14));c.setBackground(gradient(0xFFFFFFFF,0xFFF0F2FF,18));c.setElevation(dp(2));
        TextView a=text(label,13,0xFF747D98,false),b=text(value,22,color,true);c.addView(a);
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2);bp.topMargin=dp(5);c.addView(b,bp);
        View stripe=new View(this);stripe.setBackgroundColor(color);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(dp(5),dp(38));sp.gravity=Gravity.RIGHT;sp.topMargin=dp(-43);c.addView(stripe,sp);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(9);body.addView(c,p);
    }
    void addCustomer(){LinearLayout f=column();EditText name=field("نام و نام خانوادگی");EditText phone=field("شماره تماس (اختیاری)");f.addView(name);f.addView(phone);new AlertDialog.Builder(this).setTitle("مشتری جدید").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{if(name.getText().toString().trim().isEmpty()){toast("نام مشتری را وارد کن");return;}db.addCustomer(name.getText().toString().trim(),phone.getText().toString().trim());showHome();}).show();}
    EditText field(String hint){EditText e=new EditText(this);e.setHint(hint);e.setSingleLine(true);e.setTextDirection(View.TEXT_DIRECTION_RTL);return e;}
    ArrayList<Customer> getCustomers(){ArrayList<Customer>a=new ArrayList<>();Cursor c=db.customers();while(c.moveToNext())a.add(new Customer(c.getLong(0),c.getString(1),c.getString(2)));c.close();return a;}
    ArrayList<Product> getProducts(){ArrayList<Product>a=new ArrayList<>();Cursor c=db.products();while(c.moveToNext())a.add(new Product(c.getLong(0),c.getString(1),c.getLong(2)));c.close();return a;}

    void showCustomers(){
        base("فهرست مشتریان");
        EditText search=field("جست‌وجو با نام یا شماره موبایل");search.setSingleLine(true);
        search.setPadding(dp(14),dp(12),dp(14),dp(12));search.setBackground(rounded(0xFFFFFFFF,16));body.addView(search);
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(10);body.addView(list,lp);
        Runnable render=()->{
            list.removeAllViews();String q=search.getText().toString().trim().toLowerCase(new Locale("fa","IR"));
            for(Customer c:getCustomers()){
                String ph=c.phone==null?"":c.phone;
                if(!c.name.toLowerCase(new Locale("fa","IR")).contains(q)&&!ph.contains(q))continue;
                long bal=db.balance(c.id);String state=bal>0?"بدهکار":bal<0?"بستانکار":"تسویه";
                TextView row=text("●  "+c.name+"\\n"+state+": "+money(Math.abs(bal))+" تومان    "+ph,15,
                    bal>0?0xFFDF5265:bal<0?0xFF159D83:0xFF536DFE,true);
                row.setPadding(dp(15),dp(14),dp(15),dp(14));row.setBackground(gradient(0xFFFFFFFF,0xFFF7F8FF,16));row.setElevation(dp(1));
                row.setOnClickListener(v->customerDetail(c));LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.bottomMargin=dp(8);list.addView(row,rp);
            }
        };
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence a,int st,int count,int after){}public void onTextChanged(CharSequence a,int st,int before,int count){render.run();}public void afterTextChanged(Editable e){}});
        render.run();body.addView(btn("＋ افزودن مشتری",()->addCustomer()));body.addView(btn("بازگشت",()->showHome()));
    }
    void customerDetail(Customer c){base("پرونده مشتری");long bal=db.balance(c.id);card(c.name, (bal>0?"بدهکار: ":bal<0?"بستانکار: ":"تسویه: ")+money(Math.abs(bal))+" تومان",bal>0?0xFFB33A35:0xFF16866A);body.addView(btn("ثبت خرید",()->transaction(c,"BUY")));body.addView(btn("ثبت پرداخت",()->transaction(c,"PAY")));body.addView(btn("افزایش اعتبار / بستانکاری",()->transaction(c,"CREDIT")));body.addView(btn("ثبت برگشت از خرید",()->transaction(c,"RETURN")));body.addView(btn("🖨  پرینت حساب / خروجی PDF",()->printCustomerStatement(c)));body.addView(text("گردش حساب",18,DARK,true));Cursor cur=db.transactionsFor(c.id);while(cur.moveToNext()){String type=cur.getString(0);long amount=cur.getLong(1);String note=cur.getString(2);Date date=new Date(cur.getLong(3));String label=type.equals("BUY")?"خرید":type.equals("PAY")?"پرداخت":type.equals("CREDIT")?"افزایش اعتبار":"برگشت از خرید";body.addView(text(label+" · "+money(amount)+" تومان\n"+new SimpleDateFormat("yyyy/MM/dd - HH:mm",Locale.getDefault()).format(date)+(note.isEmpty()?"":"\n"+note),14,DARK,false));}cur.close();body.addView(btn("بازگشت به مشتریان",()->showCustomers()));}
    void chooseCustomerForTx(){ArrayList<Customer> a=getCustomers();if(a.isEmpty()){toast("ابتدا مشتری ثبت کن");addCustomer();return;}Spinner sp=new Spinner(this);sp.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,a));new AlertDialog.Builder(this).setTitle("انتخاب مشتری").setView(sp).setNegativeButton("انصراف",null).setPositiveButton("ادامه",(d,w)->transaction((Customer)sp.getSelectedItem(),"BUY")).show();}
    void transaction(Customer c,String type){
        if(type.equals("BUY")){ purchaseDialog(c); return; }
        LinearLayout f=column(); EditText amount=field("مبلغ به تومان"); EditText note=field("توضیحات (اختیاری)"); f.addView(text(typeTitle(type)+" برای "+c.name,17,DARK,true)); f.addView(amount); f.addView(note);
        new AlertDialog.Builder(this).setTitle("ثبت تراکنش").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ثبت",(d,w)->{try{long n=Long.parseLong(amount.getText().toString().replaceAll("[^0-9]",""));if(n<=0){toast("مبلغ باید بیشتر از صفر باشد");return;}db.addTransaction(c.id,type,n,note.getText().toString());customerDetail(c);}catch(Exception ex){toast("مبلغ معتبر وارد کن");}}).show();
    }
    void purchaseDialog(Customer c){
        LinearLayout f=column(); Spinner mode=new Spinner(this); mode.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"ثبت سریع مبلغ کلی","سبد خرید با انتخاب کالاها"}));
        EditText quickAmount=field("مبلغ کل خرید به تومان"), quickNote=field("توضیحات (اختیاری)");
        LinearLayout detailed=column(); ArrayList<Product> products=getProducts(); ArrayList<String> choices=new ArrayList<>(); choices.add("ورود دستی کالای جدید"); for(Product p:products) choices.add(p.toString());
        Spinner productSpinner=new Spinner(this); productSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,choices));
        EditText itemName=field("نام کالا"), qty=field("تعداد / مقدار (مثلاً ۲ یا ۰٫۵)"), unitPrice=field("قیمت واحد به تومان");
        TextView cart=text("هنوز کالایی به سبد اضافه نشده است",14,DARK,false), totalView=text("جمع سبد: ۰ تومان",18,GREEN,true);
        ArrayList<String> names=new ArrayList<>(); ArrayList<Double> quantities=new ArrayList<>(); ArrayList<Long> prices=new ArrayList<>(); final long[] total={0};
        productSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> a){} public void onItemSelected(android.widget.AdapterView<?> a,View v,int pos,long id){if(pos>0){Product p=products.get(pos-1);itemName.setText(p.name);unitPrice.setText(String.valueOf(p.price));}}});
        Button add=btn("＋ افزودن کالا به سبد",()->{try{String nm=itemName.getText().toString().trim();double q=Double.parseDouble(qty.getText().toString().replace(',','.').replace("٫","."));long pr=Long.parseLong(unitPrice.getText().toString().replaceAll("[^0-9]",""));if(nm.isEmpty()||q<=0||pr<0)throw new Exception();long line=Math.round(q*pr);if(productSpinner.getSelectedItemPosition()==0){db.addProduct(nm,pr);products.add(new Product(-1,nm,pr));choices.add(nm+" · "+money(pr)+" تومان");((ArrayAdapter)productSpinner.getAdapter()).notifyDataSetChanged();}names.add(nm);quantities.add(q);prices.add(pr);total[0]+=line;cart.setText(cart.getText().toString().equals("هنوز کالایی به سبد اضافه نشده است")?"• "+nm+"  ×  "+q+"  =  "+money(line):cart.getText()+"\n• "+nm+"  ×  "+q+"  =  "+money(line));totalView.setText("جمع سبد: "+money(total[0])+" تومان");itemName.setText("");qty.setText("");productSpinner.setSelection(0);}catch(Exception e){toast("نام کالا، مقدار و قیمت واحد را درست وارد کن");}});
        detailed.addView(text("انتخاب از فهرست یا ورود دستی کالا",15,DARK,true)); detailed.addView(productSpinner); detailed.addView(itemName); detailed.addView(qty); detailed.addView(unitPrice); detailed.addView(add); detailed.addView(cart); detailed.addView(totalView);
        f.addView(text("ثبت خرید برای "+c.name,17,DARK,true));f.addView(mode);f.addView(quickAmount);f.addView(quickNote);f.addView(detailed);detailed.setVisibility(View.GONE);
        mode.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> a){}public void onItemSelected(android.widget.AdapterView<?> a,View v,int pos,long id){quickAmount.setVisibility(pos==0?View.VISIBLE:View.GONE);quickNote.setVisibility(pos==0?View.VISIBLE:View.GONE);detailed.setVisibility(pos==1?View.VISIBLE:View.GONE);}});
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("ثبت خرید نسیه").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ثبت خرید",null).create();
        dialog.setOnShowListener(x->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{try{if(mode.getSelectedItemPosition()==0){long n=Long.parseLong(quickAmount.getText().toString().replaceAll("[^0-9]",""));if(n<=0)throw new Exception();db.addTransaction(c.id,"BUY",n,quickNote.getText().toString());}else{if(names.isEmpty()||total[0]<=0){toast("حداقل یک کالا به سبد اضافه کن");return;}long tx=db.addTransaction(c.id,"BUY",total[0],"خرید با جزئیات کالاها");for(int i=0;i<names.size();i++)db.addItem(tx,names.get(i),quantities.get(i),prices.get(i));}dialog.dismiss();customerDetail(c);}catch(Exception e){toast("مبلغ یا اطلاعات خرید معتبر نیست");}}));
        dialog.show();
    }
    String typeTitle(String t){return t.equals("BUY")?"خرید نسیه":t.equals("PAY")?"پرداخت مشتری":t.equals("CREDIT")?"افزایش اعتبار":"برگشت از خرید";}
    String htmlEscape(String s){if(s==null)return "";return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&#39;");}
    void printCustomerStatement(Customer customer){
        Cursor cur=db.transactionsForPrint(customer.id);
        StringBuilder rows=new StringBuilder(); long running=0; int count=0;
        while(cur.moveToNext()){
            String type=cur.getString(0); long amount=cur.getLong(1); String note=cur.getString(2); long stamp=cur.getLong(3);
            String label=type.equals("BUY")?"خرید نسیه":type.equals("PAY")?"پرداخت":type.equals("CREDIT")?"افزایش اعتبار":"برگشت از خرید";
            if(type.equals("BUY"))running+=amount; else running-=amount;
            String date=new SimpleDateFormat("yyyy/MM/dd - HH:mm",new Locale("fa","IR")).format(new Date(stamp));
            rows.append("<tr><td>").append(++count).append("</td><td>").append(htmlEscape(date)).append("</td><td>").append(label).append("</td><td>").append(money(amount)).append("</td><td>").append(running>0?"بدهکار":running<0?"بستانکار":"تسویه").append(" ").append(money(Math.abs(running))).append("</td><td>").append(htmlEscape(note)).append("</td></tr>");
        }
        cur.close();
        long balance=db.balance(customer.id);
        String state=balance>0?"بدهکار":balance<0?"بستانکار":"تسویه";
        String shopName=db.getSetting("shop_name","").trim(), shopPhone=db.getSetting("shop_phone","").trim(), shopAddress=db.getSetting("shop_address","").trim(), logoData=db.getSetting("shop_logo_base64","");
        String logoHtml=logoData.isEmpty()?"":"<img class='logo' src='data:image/jpeg;base64,"+logoData+"' />";
        String shopHeader=logoHtml+(shopName.isEmpty()?"سوپرمارکت":htmlEscape(shopName))+((shopPhone.isEmpty()&&shopAddress.isEmpty())?"":"<div class='shop-contact'>"+(shopPhone.isEmpty()?"":"تلفن: "+htmlEscape(shopPhone))+((shopPhone.isEmpty()||shopAddress.isEmpty())?"":"　 |　")+(shopAddress.isEmpty()?"":"نشانی: "+htmlEscape(shopAddress))+"</div>");
        String html="<!doctype html><html lang='fa' dir='rtl'><head><meta charset='UTF-8'><meta name='viewport' content='width=device-width, initial-scale=1'><style>"
          +"@page{size:A4 portrait;margin:14mm}*{box-sizing:border-box}body{font-family:sans-serif;direction:rtl;color:#172b27;font-size:10pt;margin:0}h1{text-align:center;font-size:19pt;margin:0 0 5mm} .sub{text-align:center;color:#53635e;margin-bottom:8mm}.shop-contact{text-align:center;font-size:9pt;color:#53635e;margin:2mm 0 5mm}.logo{display:block;max-width:24mm;max-height:18mm;object-fit:contain;margin:0 auto 2mm}.meta{border:1px solid #9aa9a3;padding:4mm;border-radius:3mm;margin-bottom:6mm;line-height:2}.balance{font-size:14pt;font-weight:bold;margin-top:2mm}table{width:100%;border-collapse:collapse;font-size:8.5pt}th,td{border:1px solid #9aa9a3;padding:2.2mm;text-align:center;vertical-align:middle}th{background:#eaf1ee}td:last-child{text-align:right}.foot{margin-top:8mm;font-size:8pt;color:#52615c;text-align:center}</style></head><body>"
          +"<h1>"+shopHeader+"</h1><div class='sub'>صورتحساب مشتری</div><div class='meta'><b>نام مشتری:</b> "+htmlEscape(customer.name)+"<br><b>تاریخ چاپ:</b> "+htmlEscape(new SimpleDateFormat("yyyy/MM/dd - HH:mm",new Locale("fa","IR")).format(new Date()))+"<div class='balance'>مانده نهایی: "+state+" · "+money(Math.abs(balance))+" تومان</div></div>"
          +"<table><thead><tr><th>ردیف</th><th>تاریخ</th><th>شرح</th><th>مبلغ (تومان)</th><th>مانده پس از تراکنش</th><th>توضیحات</th></tr></thead><tbody>"+rows+"</tbody></table><div class='foot'>این صورتحساب بر اساس تراکنش‌های ثبت‌شده در دفتر حساب تهیه شده است.</div></body></html>";
        WebView web=new WebView(this); web.getSettings().setDefaultTextEncodingName("UTF-8");
        web.setWebViewClient(new WebViewClient(){@Override public void onPageFinished(WebView view,String url){PrintManager pm=(PrintManager)getSystemService(Context.PRINT_SERVICE);PrintDocumentAdapter adapter=view.createPrintDocumentAdapter("حساب-"+customer.name);PrintAttributes attrs=new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setResolution(new PrintAttributes.Resolution("pdf", "pdf", 300, 300)).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build();pm.print("صورتحساب-"+customer.name,adapter,attrs);}});
        web.loadDataWithBaseURL(null,html,"text/html","UTF-8",null);
    }
    void shopSettings(){
        LinearLayout f=column();EditText name=field("نام سوپرمارکت");EditText phone=field("شماره تماس");EditText address=field("نشانی مغازه");
        name.setText(db.getSetting("shop_name",""));phone.setText(db.getSetting("shop_phone",""));address.setText(db.getSetting("shop_address",""));
        f.addView(text("این مشخصات در سربرگ صورتحساب PDF مشتری چاپ می‌شوند.",13,DARK,false));f.addView(name);f.addView(phone);f.addView(address);
        Button logo=btn(db.getSetting("shop_logo_base64","").isEmpty()?"انتخاب لوگوی سوپرمارکت":"تغییر لوگوی سوپرمارکت",()->{Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT);pick.addCategory(Intent.CATEGORY_OPENABLE);pick.setType("image/*");startActivityForResult(pick,12);});f.addView(logo);
        new AlertDialog.Builder(this).setTitle("مشخصات سوپرمارکت").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{db.setSetting("shop_name",name.getText().toString().trim());db.setSetting("shop_phone",phone.getText().toString().trim());db.setSetting("shop_address",address.getText().toString().trim());toast("مشخصات سوپرمارکت ذخیره شد");showHome();}).show();
    }
    void showProducts(){base("مدیریت کالاها");body.addView(btn("＋ افزودن کالا",()->addProduct()));for(Product p:getProducts())body.addView(text(p.name+"  ·  "+money(p.price)+" تومان",16,DARK,false));body.addView(btn("بازگشت",()->showHome()));}
    void addProduct(){LinearLayout f=column();EditText n=field("نام کالا");EditText p=field("قیمت واحد به تومان");f.addView(n);f.addView(p);new AlertDialog.Builder(this).setTitle("کالای جدید").setView(f).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{try{if(n.getText().toString().trim().isEmpty())throw new Exception();db.addProduct(n.getText().toString().trim(),Long.parseLong(p.getText().toString().replaceAll("[^0-9]","")));showProducts();}catch(Exception e){toast("نام و قیمت معتبر وارد کن");}}).show();}
    void showReports(){base("گزارش حساب‌ها");for(Customer c:getCustomers()){long b=db.balance(c.id);if(b!=0)body.addView(text(c.name+"  |  "+(b>0?"بدهکار":"بستانکار")+"  "+money(Math.abs(b))+" تومان",16,b>0?0xFFB33A35:0xFF16866A,false));}body.addView(btn("بازگشت",()->showHome()));}
    void backup(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/octet-stream");i.putExtra(Intent.EXTRA_TITLE,"daftar-hesab-backup.dbbackup");startActivityForResult(i,10);}
    void restore(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");startActivityForResult(i,11);}
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(res!=RESULT_OK||data==null)return;try{Uri u=data.getData();if(req==12){try(InputStream in=getContentResolver().openInputStream(u)){Bitmap original=BitmapFactory.decodeStream(in);if(original==null)throw new Exception("تصویر قابل خواندن نیست");int w=original.getWidth(),h=original.getHeight();float scale=Math.min(512f/Math.max(w,h),1f);Bitmap small=Bitmap.createScaledBitmap(original,Math.max(1,(int)(w*scale)),Math.max(1,(int)(h*scale)),true);ByteArrayOutputStream out=new ByteArrayOutputStream();small.compress(Bitmap.CompressFormat.JPEG,82,out);db.setSetting("shop_logo_base64",Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP));toast("لوگوی سوپرمارکت ذخیره شد");shopSettings();}return;}File dbFile=getDatabasePath(DbHelper.DB_NAME);if(req==10){try(InputStream in=new FileInputStream(dbFile);OutputStream out=getContentResolver().openOutputStream(u)){byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,n);}toast("نسخه پشتیبان ذخیره شد");}else if(req==11){db.close();try(InputStream in=getContentResolver().openInputStream(u);OutputStream out=new FileOutputStream(dbFile)){byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,n);}db=new DbHelper(this);toast("بازیابی انجام شد");showHome();}}catch(Exception e){toast("عملیات ناموفق بود: "+e.getMessage());}}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
